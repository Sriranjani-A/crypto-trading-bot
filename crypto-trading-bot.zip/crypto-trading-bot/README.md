# Binance Futures Trading Bot (Testnet)

This project is a simplified Python-based trading bot that interacts with the Binance USDT-M Futures Testnet. It was developed as part of the evaluation task for the Junior Python Developer role.

The bot allows users to place Buy or Sell orders using Market, Limit, or Stop-Market order types through a simple command-line interface. All API responses and errors are logged, and the bot uses a reusable class-based structure for clarity and maintainability.

---

## Features

1 Connects to Binance Futures Testnet via secure API
2 Supports placing Market, Limit, and Stop-Market orders
3 Handles both Buy and Sell operations
4 Accepts command-line input for order parameters
5 Logs all API requests and errors to a log file
6 Uses a .env file to securely store API keys
7 Built using a structured, reusable class (BasicBot)

---

## Technologies Used

Python 3
python-binance – Binance API client
python-dotenv – Load API keys securely from .env
logging – Built-in Python logging for tracking activity

---

## Project Structure

| File                | Description                                          |
|---------------------|------------------------------------------------------|
| basic_bot.py        | Main bot script that connects to Binance API         |
| .env.example        | Example file showing how to set up environment keys  |
| trading_bot.log     | Stores API responses and any runtime errors          |
| README.md           | Project documentation                                |


---

## How to Set Up and Run

1. **Install required libraries:**

pip install python-binance python-dotenv

## creating env 

API_KEY=your_binance_testnet_api_key
API_SECRET=your_binance_testnet_api_secret

## to run bot 

python basic_bot.py

