# --------------------------------------
# Project: Binance Futures Testnet Trading Bot
# Author: Sri Ranjani
# Purpose: Submit as part of Junior Python Developer Evaluation Task
# Features:
#   1 Connect to Binance Testnet
#   2 Place Market, Limit & Stop Orders
#   3 Support Buy & Sell
#   4 Accept CLI input
#   5 Log API responses & errors
# --------------------------------------

from binance.client import Client
from binance.enums import *
from dotenv import load_dotenv
import logging
import os

# ------------------------------
# Load API credentials securely from .env file
# ------------------------------
load_dotenv()
API_KEY = os.getenv("API_KEY")
API_SECRET = os.getenv("API_SECRET")

# ------------------------------
# Logging configuration
# ------------------------------
logging.basicConfig(
    filename='trading_bot.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# ------------------------------
# BasicBot Class Definition
# ------------------------------
class BasicBot:
    def __init__(self, api_key, api_secret, testnet=True):
        self.client = Client(api_key, api_secret)
        if testnet:
            self.client.FUTURES_URL = 'https://testnet.binancefuture.com/fapi'

    def place_order(self, symbol, side, order_type, quantity, price=None, stop_price=None):
        try:
            if order_type == ORDER_TYPE_MARKET:
                order = self.client.futures_create_order(
                    symbol=symbol,
                    side=side,
                    type=ORDER_TYPE_MARKET,
                    quantity=quantity
                )
            elif order_type == ORDER_TYPE_LIMIT:
                order = self.client.futures_create_order(
                    symbol=symbol,
                    side=side,
                    type=ORDER_TYPE_LIMIT,
                    timeInForce=TIME_IN_FORCE_GTC,
                    quantity=quantity,
                    price=price
                )
            elif order_type == ORDER_TYPE_STOP_MARKET:
                order = self.client.futures_create_order(
                    symbol=symbol,
                    side=side,
                    type=ORDER_TYPE_STOP_MARKET,
                    stopPrice=stop_price,
                    closePosition=False,
                    timeInForce=TIME_IN_FORCE_GTC,
                    quantity=quantity
                )
            else:
                print("Unsupported order type.")
                return None

            print("Order placed successfully!")
            print(order)
            logging.info(order)
            return order

        except Exception as e:
            print("Error placing order:", str(e))
            logging.error(str(e))
            return None

# ------------------------------
# Function to get user input via CLI
# ------------------------------
def get_user_input():
    print("\nBinance Futures Testnet Trading Bot\n")

    symbol = input("Enter symbol (e.g., BTCUSDT): ").upper()
    side_input = input("Buy or Sell? ").lower()
    side = SIDE_BUY if side_input == "buy" else SIDE_SELL

    print("Choose order type: \n1. Market\n2. Limit\n3. Stop-Market")
    order_choice = input("Enter 1/2/3: ").strip()

    if order_choice == "1":
        order_type = ORDER_TYPE_MARKET
    elif order_choice == "2":
        order_type = ORDER_TYPE_LIMIT
    elif order_choice == "3":
        order_type = ORDER_TYPE_STOP_MARKET
    else:
        print("Invalid choice. Defaulting to Market order.")
        order_type = ORDER_TYPE_MARKET

    quantity = float(input("Enter quantity (e.g., 0.001): "))

    price = None
    stop_price = None

    if order_type == ORDER_TYPE_LIMIT:
        price = input("Enter limit price (e.g., 60000): ")
    elif order_type == ORDER_TYPE_STOP_MARKET:
        stop_price = input("Enter stop price (e.g., 30000): ")

    return symbol, side, order_type, quantity, price, stop_price

# ------------------------------
# Main Script
# ------------------------------
if __name__ == "__main__":
    symbol, side, order_type, quantity, price, stop_price = get_user_input()

    bot = BasicBot(API_KEY, API_SECRET)
    bot.place_order(symbol, side, order_type, quantity, price, stop_price)
